﻿using System;
using System.Threading.Tasks;
using RetailInventorySystem.Models;
using Microsoft.EntityFrameworkCore;

class Program
{
    static async Task Main(string[] args)
    {
        using var context = new AppDbContext();

        // Make sure DB and schema exist
        await context.Database.EnsureCreatedAsync();

        // 💣 Clear existing data
        context.Products.RemoveRange(context.Products);
        context.Categories.RemoveRange(context.Categories);
        await context.SaveChangesAsync();

        // 📦 Insert fresh categories
        var electronics = new Category { Name = "Electronics" };
        var groceries = new Category { Name = "Groceries" };
        await context.Categories.AddRangeAsync(electronics, groceries);

        // 📦 Insert fresh products
        var laptop = new Product { Name = "Laptop", Price = 75000, Category = electronics };
        var rice = new Product { Name = "Rice Bag", Price = 1200, Category = groceries };
        await context.Products.AddRangeAsync(laptop, rice);

        // ✅ Save everything
        await context.SaveChangesAsync();

        Console.WriteLine("✅ Data inserted successfully!");
    }
}
