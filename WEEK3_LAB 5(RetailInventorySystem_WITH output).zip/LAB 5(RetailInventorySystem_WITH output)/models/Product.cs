using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using RetailInventorySystem.Models;

namespace RetailInventorySystem.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }

        public string Name { get; set; } = string.Empty;

        public double Price { get; set; }

        // Foreign Key for Category
        public int CategoryId { get; set; }
        public Category Category { get; set; } = null!;

        // Foreign Key for Supplier (optional for now)
        public int? SupplierId { get; set; }
        public Supplier? Supplier { get; set; }
    }
}
