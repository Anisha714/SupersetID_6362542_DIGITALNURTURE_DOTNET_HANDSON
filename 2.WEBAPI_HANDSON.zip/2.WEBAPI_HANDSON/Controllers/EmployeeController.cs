﻿using Microsoft.AspNetCore.Mvc;
using FirstWebAPI.Models;
using FirstWebAPI.Filters;


namespace FirstWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [CustomAuthFilter] 
    public class EmployeeController : ControllerBase

    {
        private static List<Employee> _employees;

        static EmployeeController()
        {
            _employees = GetStandardEmployeeList();
        }

        // GET: api/employee
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<List<Employee>> Get()
        {
            return Ok(_employees);
        }

        // GET: api/employee/1
        [HttpGet("{id}")]
        public ActionResult<Employee> Get(int id)
        {
            var emp = _employees.FirstOrDefault(e => e.Id == id);
            if (emp == null)
                return NotFound();
            return Ok(emp);
        }

        // POST: api/employee
        [HttpPost]
        public ActionResult<Employee> Post([FromBody] Employee emp)
        {
            _employees.Add(emp);
            return Ok(emp);
        }

        // PUT: api/employee/1
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Employee updatedEmp)
        {
            var emp = _employees.FirstOrDefault(e => e.Id == id);
            if (emp == null)
                return NotFound();

            emp.Name = updatedEmp.Name;
            emp.Salary = updatedEmp.Salary;
            emp.Permanent = updatedEmp.Permanent;
            emp.Department = updatedEmp.Department;
            emp.Skills = updatedEmp.Skills;
            emp.DateOfBirth = updatedEmp.DateOfBirth;

            return Ok(emp);
        }

        // Static method for preloading data
        private static List<Employee> GetStandardEmployeeList()
        {
            return new List<Employee>
            {
                new Employee
                {
                    Id = 1,
                    Name = "Anisha Raj",
                    Salary = 50000,
                    Permanent = true,
                    Department = new Department { Id = 101, Name = "IT" },
                    Skills = new List<Skill>
                    {
                        new Skill { Id = 1, Name = "C#" },
                        new Skill { Id = 2, Name = "SQL" }
                    },
                    DateOfBirth = new DateTime(2000, 5, 12)
                },
                new Employee
                {
                    Id = 2,
                    Name = "Ravi Sharma",
                    Salary = 45000,
                    Permanent = false,
                    Department = new Department { Id = 102, Name = "HR" },
                    Skills = new List<Skill>
                    {
                        new Skill { Id = 3, Name = "Communication" }
                    },
                    DateOfBirth = new DateTime(1999, 8, 25)
                }
            };
        }
    }
}
